aoc -board=p520_hpc_m210h_g3x16 -fp-relaxed -DINTEL_CL -o fft2d_mx FFT_2d.cl
